#!/usr/bin/env python3

import socket
import struct
import sys
import time
import random


class ModbusUDP:

    def __init__(self, host, port=5001, slave_id=1):
        self.host = host
        self.port = port
        self.slave_id = slave_id
        self.timeout = 3

    def _send(self, pdu):

        transaction_id = random.randint(0, 65535)

        mbap = struct.pack(
            ">HHHB",
            transaction_id,    # Transaction ID
            0,                 # Protocol ID
            len(pdu) + 1,      # Length
            self.slave_id      # Unit ID
        )

        packet = mbap + pdu

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self.timeout)

        try:
            sock.sendto(packet, (self.host, self.port))
            response, _ = sock.recvfrom(1024)
            return response
        finally:
            sock.close()

    def read_holding_registers(self, address, count):

        pdu = struct.pack(
            ">BHH",
            3,
            address,
            count
        )

        response = self._send(pdu)

        byte_count = response[8]

        registers = []

        for i in range(0, byte_count, 2):

            value = struct.unpack(
                ">H",
                response[9 + i:11 + i]
            )[0]

            registers.append(value)

        return registers

    def write_single_register(self, address, value):

        pdu = struct.pack(
            ">BHH",
            6,
            address,
            value
        )

        self._send(pdu)


class Chamber:

    REG_STATUS = 30
    REG_CURRENT_TEMP = 101
    REG_SET_TEMP = 102
    REG_POWER = 105
    REG_SET_TEMP_CMD = 130

    def __init__(self, ip):
        self.mb = ModbusUDP(ip)

    @staticmethod
    def reg_to_temp(value):

        if value > 32767:
            value -= 65536

        return value / 100.0

    @staticmethod
    def temp_to_reg(temp):

        value = int(round(temp * 100))

        if value < 0:
            value += 65536

        return value

    def get_status(self):

        value = self.mb.read_holding_registers(
            self.REG_STATUS,
            1
        )

        return value[0]

    def get_current_temp(self):

        value = self.mb.read_holding_registers(
            self.REG_CURRENT_TEMP,
            1
        )

        return self.reg_to_temp(value[0])

    def get_set_temp(self):

        value = self.mb.read_holding_registers(
            self.REG_SET_TEMP,
            1
        )

        return self.reg_to_temp(value[0])

    def show_temp(self):

        current = self.get_current_temp()
        target = self.get_set_temp()

        print(
            f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
            f"=> Set {target:.2f}C, Now {current:.2f}C"
        )

    def set_temp(self, temp):

        value = self.temp_to_reg(temp)

        self.mb.write_single_register(
            self.REG_SET_TEMP_CMD,
            value
        )

        time.sleep(1)

        verify = self.get_set_temp()

        print(
            f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
            f"=> Set Temp {verify:.2f}C"
        )

    def on(self):

        self.mb.write_single_register(
            self.REG_POWER,
            1
        )

        print("Chamber ON")

    def off(self):

        self.mb.write_single_register(
            self.REG_POWER,
            0
        )

        print("Chamber OFF")

    def wait_until_target(
            self,
            interval=60,
            tolerance=1.0,
            match_count=3):

        matched = 0

        print(
            f"Waiting Temp "
            f"(±{tolerance}C, "
            f"{interval}s, "
            f"{match_count} times)"
        )

        while True:

            current = self.get_current_temp()
            target = self.get_set_temp()

            diff = abs(target - current)

            print(
                f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
                f"=> Set {target:.2f}C, "
                f"Now {current:.2f}C"
            )

            if diff <= tolerance:
                matched += 1
                print(
                    f"Matched {matched}/{match_count}"
                )
            else:
                matched = 0

            if matched >= match_count:
                print("Temperature reached.")
                return

            time.sleep(interval)


def show_help():

    print("""
====================================================

Chamber Control Tool (Modbus UDP)

====================================================

Usage

    python3 chamber.py <IP> [Options]

Options

    -Q
        Show temperature

    -S <Temp>
        Set target temperature

    -O
        Turn chamber ON

    -F
        Turn chamber OFF

    -W
        Wait until temperature reaches target

    -T <Seconds>
        Check interval
        Default = 60

    -L <Tolerance>
        Default = 1.0

    -R <Count>
        Consecutive match count
        Default = 3

Examples

    Query Temp

        python3 chamber.py 192.168.1.100 -Q

    Set 25C

        python3 chamber.py 192.168.1.100 -S 25

    Set -40C

        python3 chamber.py 192.168.1.100 -S -40

    Turn ON

        python3 chamber.py 192.168.1.100 -O

    Turn OFF

        python3 chamber.py 192.168.1.100 -F

    Set and Turn ON

        python3 chamber.py 192.168.1.100 -S -40 -O

    Set and Wait

        python3 chamber.py 192.168.1.100 -S -40 -O -W

====================================================
""")

    sys.exit(0)


def main():

    if len(sys.argv) < 2:
        show_help()

    if sys.argv[1] in ["-h", "--help"]:
        show_help()

    ip = sys.argv[1]

    query = False
    turn_on = False
    turn_off = False
    wait = False

    target_temp = None

    interval = 60
    tolerance = 1.0
    match_count = 3

    i = 2

    while i < len(sys.argv):

        arg = sys.argv[i].upper()

        if arg == "-Q":
            query = True

        elif arg == "-O":
            turn_on = True

        elif arg == "-F":
            turn_off = True

        elif arg == "-W":
            wait = True

        elif arg == "-S":
            target_temp = float(sys.argv[i + 1])
            i += 1

        elif arg == "-T":
            interval = int(sys.argv[i + 1])
            i += 1

        elif arg == "-L":
            tolerance = float(sys.argv[i + 1])
            i += 1

        elif arg == "-R":
            match_count = int(sys.argv[i + 1])
            i += 1

        else:
            print("Unknown parameter :", sys.argv[i])
            return

        i += 1

    chamber = Chamber(ip)

    try:

        print("Status =", chamber.get_status())

        if query:
            chamber.show_temp()

        if target_temp is not None:
            chamber.set_temp(target_temp)

        if turn_on:
            chamber.on()

        if turn_off:
            chamber.off()

        if wait:
            chamber.wait_until_target(
                interval,
                tolerance,
                match_count
            )

    except Exception as ex:
        print("Error:", ex)


if __name__ == "__main__":
    main()