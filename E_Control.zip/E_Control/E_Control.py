#!/usr/bin/env python3

from pymodbus.client.sync import ModbusUdpClient
import sys
import time


class Chamber:

    SLAVE_ID = 1

    REG_STATUS = 30
    REG_CURRENT_TEMP = 101
    REG_SET_TEMP = 102
    REG_POWER = 105
    REG_SET_TEMP_CMD = 130

    def __init__(self, ip, port=5001):

        self.client = ModbusUdpClient(
            ip,
            port=port
        )

    def connect(self):

        return self.client.connect()

    def close(self):

        self.client.close()

    @staticmethod
    def reg_to_temp(value):

        if value > 32767:
            value -= 65536

        return value / 100.0

    @staticmethod
    def temp_to_reg(temp):

        value = int(round(temp * 100))

        if value < 0:
            value += 65536

        return value

    def get_status(self):

        result = self.client.read_holding_registers(
            self.REG_STATUS,
            1,
            unit=self.SLAVE_ID
        )

        if result.isError():
            return 99

        return result.registers[0]

    def get_current_temp(self):

        result = self.client.read_holding_registers(
            self.REG_CURRENT_TEMP,
            1,
            unit=self.SLAVE_ID
        )

        if result.isError():
            raise Exception("Read current temp failed")

        return self.reg_to_temp(
            result.registers[0]
        )

    def get_set_temp(self):

        result = self.client.read_holding_registers(
            self.REG_SET_TEMP,
            1,
            unit=self.SLAVE_ID
        )

        if result.isError():
            raise Exception("Read set temp failed")

        return self.reg_to_temp(
            result.registers[0]
        )

    def show_temp(self):

        now = self.get_current_temp()
        target = self.get_set_temp()

        print(
            f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
            f"=> Set {target:.2f}C, "
            f"Now {now:.2f}C"
        )

    def set_temp(self, temp):

        value = self.temp_to_reg(temp)

        self.client.write_register(
            self.REG_SET_TEMP_CMD,
            value,
            unit=self.SLAVE_ID
        )

        time.sleep(1)

        verify = self.get_set_temp()

        print(
            f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
            f"=> Set Temp {verify:.2f}C"
        )

    def on(self):

        self.client.write_register(
            self.REG_POWER,
            1,
            unit=self.SLAVE_ID
        )

        print("Chamber ON")

    def off(self):

        self.client.write_register(
            self.REG_POWER,
            0,
            unit=self.SLAVE_ID
        )

        print("Chamber OFF")

    def wait_until_target(
            self,
            interval=60,
            tolerance=1.0,
            match_count=3):

        matched = 0

        print(
            f"Waiting Temp "
            f"(±{tolerance}C, "
            f"{interval}s, "
            f"{match_count} times)"
        )

        while True:

            now = self.get_current_temp()
            target = self.get_set_temp()

            diff = abs(target - now)

            print(
                f"{time.strftime('%Y/%m/%d %H:%M:%S')} "
                f"=> Set {target:.2f}C, "
                f"Now {now:.2f}C"
            )

            if diff <= tolerance:
                matched += 1
                print(
                    f"Matched {matched}/{match_count}"
                )
            else:
                matched = 0

            if matched >= match_count:
                print("Target temperature reached.")
                return

            time.sleep(interval)


def show_help():

    print("""
==================================================

Chamber Control Tool

Usage

    python3 chamber.py <IP> [Options]

Options

    -Q
        Query Temperature

    -S <Temp>
        Set Temperature

    -O
        Chamber ON

    -F
        Chamber OFF

    -W
        Wait Temperature Stable

    -T <Seconds>
        Check Interval
        Default = 60

    -L <Tolerance>
        Default = 1.0

    -R <Count>
        Default = 3

Examples

    Query

        python3 chamber.py 192.168.1.100 -Q

    Set 25C

        python3 chamber.py 192.168.1.100 -S 25

    Set -40C

        python3 chamber.py 192.168.1.100 -S -40

    ON

        python3 chamber.py 192.168.1.100 -O

    OFF

        python3 chamber.py 192.168.1.100 -F

    Set + ON

        python3 chamber.py 192.168.1.100 -S -40 -O

    Set + ON + Wait

        python3 chamber.py 192.168.1.100 -S -40 -O -W

Register Map

    30    Status
    101   Current Temp
    102   Set Temp
    105   Chamber Power
    130   Set Temp Command

==================================================
""")

    sys.exit(0)


def main():

    if len(sys.argv) < 2:
        show_help()

    if sys.argv[1] in ["-h", "--help"]:
        show_help()

    ip = sys.argv[1]

    query_temp = False
    power_on = False
    power_off = False
    wait_mode = False

    target_temp = None

    interval = 60
    tolerance = 1.0
    match_count = 3

    i = 2

    while i < len(sys.argv):

        arg = sys.argv[i].upper()

        if arg == "-Q":
            query_temp = True

        elif arg == "-O":
            power_on = True

        elif arg == "-F":
            power_off = True

        elif arg == "-W":
            wait_mode = True

        elif arg == "-S":
            target_temp = float(sys.argv[i + 1])
            i += 1

        elif arg == "-T":
            interval = int(sys.argv[i + 1])
            i += 1

        elif arg == "-L":
            tolerance = float(sys.argv[i + 1])
            i += 1

        elif arg == "-R":
            match_count = int(sys.argv[i + 1])
            i += 1

        else:
            print("Unknown parameter:", sys.argv[i])
            return

        i += 1

    chamber = Chamber(ip)

    if not chamber.connect():
        print(f"Cannot connect to {ip}:5001")
        return

    try:

        print("Status =", chamber.get_status())

        if query_temp:
            chamber.show_temp()

        if target_temp is not None:
            chamber.set_temp(target_temp)

        if power_on:
            chamber.on()

        if power_off:
            chamber.off()

        if wait_mode:
            chamber.wait_until_target(
                interval,
                tolerance,
                match_count
            )

    finally:
        chamber.close()


if __name__ == "__main__":
    main()